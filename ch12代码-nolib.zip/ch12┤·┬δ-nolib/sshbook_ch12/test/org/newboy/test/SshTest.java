package org.newboy.test;

import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SshTest {

	/**
	 * ����spring��hibernate���ϵķ���
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		testSave();
		
	}

	public static void testSave() {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		DeptDao deptdao = (DeptDao) context.getBean("deptDao");
        Dept dept =new Dept(50, "TestDept", "gz"); 
		deptdao.save(dept);
	}

	public static void testGetAll() {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"applicationContext.xml");
		DeptDao deptdao = (DeptDao) context.getBean("deptDao");
		List<Dept> list = deptdao.getAllDept();
		for (Dept dept : list) {
			System.out.println(dept.getDeptno());
		}
		System.out.println("size:" + list.size());
	}

}
