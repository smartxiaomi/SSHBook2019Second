package org.newboy.test;

public class TxTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		org.springframework.orm.hibernate3.HibernateTransactionManager m;
		org.springframework.orm.hibernate4.HibernateTransactionManager m2;
		

	}

}
