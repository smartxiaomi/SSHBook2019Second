package org.newboy.test;

import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.newboy.service.DeptService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TxAnnotationTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		//testGetAll();
		testSave();
		testGetAll();
	}
	public static void testGetAll() {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"txAnnotation.xml");
		DeptService deptService = (DeptService) context.getBean("deptService");
		List<Dept> list = deptService.getAllDept();
		for (Dept dept : list) {
			System.out.println(dept.getDeptno());
		}
		System.out.println("size:" + list.size());
	}
	
	
	public static void testSave() {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"txAnnotation.xml");
		DeptService deptService = (DeptService) context.getBean("deptService");
        Dept dept =new Dept(60, "TestDeptB", "beijing"); 
        deptService.save(dept);
	}
}
