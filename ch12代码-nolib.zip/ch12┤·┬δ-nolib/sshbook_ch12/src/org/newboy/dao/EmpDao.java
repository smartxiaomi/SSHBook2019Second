package org.newboy.dao;

import java.util.List;

import org.newboy.bean.EmpCondition;
import org.newboy.entity.Emp;

public interface EmpDao {
	
	/**
	 * ��ѯ
	 * @param condition
	 * @return
	 */
	public int getCount(EmpCondition condition);
	
	public List<Emp> getEmployees(EmpCondition condition);

}
