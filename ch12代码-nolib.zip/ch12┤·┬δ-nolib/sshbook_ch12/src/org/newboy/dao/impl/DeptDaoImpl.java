package org.newboy.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.newboy.dao.DeptDao;
import org.newboy.dao.HibernateUtil;
import org.newboy.entity.Dept;

public class DeptDaoImpl implements DeptDao {

	public List<Dept> getAllDept() {

		Session session = HibernateUtil.getSession();
		Query query = session.createQuery("select d from Dept d");
		return query.list();
	}

	public int save(Dept dept) {
		Session session = HibernateUtil.getSession();
		Transaction tx = session.beginTransaction();
		int id = 0;
		try {
			tx.begin();
			id = (Integer) session.save(dept);
			tx.commit();

		} catch (Exception e) {
			e.printStackTrace();
			tx.rollback();
		}

		return id;
	}

	public Dept getDeptByCondition(Dept dept) {
		// TODO Auto-generated method stub
		return null;
	}

}
