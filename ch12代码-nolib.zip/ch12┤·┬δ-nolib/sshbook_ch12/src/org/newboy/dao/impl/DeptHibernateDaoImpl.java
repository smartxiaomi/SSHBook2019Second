package org.newboy.dao.impl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.SessionFactory;
import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;

public class DeptHibernateDaoImpl implements DeptDao {
	//Hibernateԭ����SessionFactory
	private SessionFactory sessionFactory;
	
	public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

	public List<Dept> getAllDept() {
		Query query =sessionFactory.getCurrentSession().createQuery("from Dept");
		return query.list();
	}

	public Dept getDeptByCondition(Dept dept) {
		return null;
	}

	public int save(Dept dept) {
	
		return 0;
	}

}
