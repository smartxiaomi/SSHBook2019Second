package org.newboy.dao.impl;

import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

public class DeptDaoSupportImpl extends HibernateDaoSupport implements DeptDao {

	@SuppressWarnings("unchecked")
	public List<Dept> getAllDept() {
		return (List<Dept>)super.getHibernateTemplate().find("from Dept");
	}

	public int save(Dept dept) {
		return (Integer)super.getHibernateTemplate().save(dept);
	}
	
	public Dept getDeptByCondition(Dept dept) {
           List<Dept> list =super.getHibernateTemplate().findByExample(dept);
		if(list!=null&&list.size()>0){
			return list.get(0);
		}
		return null;
	}

}
