package org.newboy.entity;

import java.util.Date;

/**
 * Ա��ʵ����
 */
public class Emp implements java.io.Serializable {
	private Dept dept; // ���Ŷ��󣬶��һ�Ĺ�ϵ
	private Integer empno; // Ա�����
	private String ename; // Ա������
	private String job; // ְλ
	private Integer mgr; // ��˾Ա���ı��
	private Date hiredate; // ��ְ����
	private Double sal; // ����
	private Double comm; // ����

	public Emp(Integer empno, String ename) {
		super();
		this.empno = empno;
		this.ename = ename;
	}

	public Emp() {
	}

	public Emp(Integer empno) {
		this.empno = empno;
	}

@Override
public String toString() {
	return "���:" + empno + ", ����:" + ename + ", ְλ:" + job + ", ��˾ID:" + mgr
			+ ", ��ְ����:" + hiredate + ", ����:" + sal + ", ����:" + comm;
}

	public Emp(Integer empno, Dept dept, String ename, String job, Integer mgr, Date hiredate,
			Double sal, Double comm) {
		this.empno = empno;
		this.dept = dept;
		this.ename = ename;
		this.job = job;
		this.mgr = mgr;
		this.hiredate = hiredate;
		this.sal = sal;
		this.comm = comm;
	}

	public Integer getEmpno() {
		return this.empno;
	}

	public void setEmpno(Integer empno) {
		this.empno = empno;
	}

	public Dept getDept() {
		return this.dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public String getEname() {
		return this.ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return this.job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Integer getMgr() {
		return this.mgr;
	}

	public void setMgr(Integer mgr) {
		this.mgr = mgr;
	}

	public Date getHiredate() {
		return this.hiredate;
	}

	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}

	public Double getSal() {
		return this.sal;
	}

	public void setSal(Double sal) {
		this.sal = sal;
	}

	public Double getComm() {
		return this.comm;
	}

	public void setComm(Double comm) {
		this.comm = comm;
	}

}