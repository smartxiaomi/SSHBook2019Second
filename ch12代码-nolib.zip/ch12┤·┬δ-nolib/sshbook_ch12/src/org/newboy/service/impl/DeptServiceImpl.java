package org.newboy.service.impl;


import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.newboy.service.DeptService;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

public class DeptServiceImpl implements DeptService {
	
	private DeptDao deptDao;
	
	private TransactionTemplate transactionTemplate;
	
	public void setTransactionManager(PlatformTransactionManager transactionManager){
		this.transactionTemplate=new TransactionTemplate(transactionManager);
		
	}
	
	// ���������ģ����
	public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
		this.transactionTemplate = transactionTemplate;
	}

	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	public List<Dept> getAllDept() {
		return deptDao.getAllDept();
	}

	public Integer save(final Dept dept) {
		return (Integer) this.transactionTemplate
				.execute(new TransactionCallback() {

					public Object doInTransaction(TransactionStatus arg0) {
						return (Integer) deptDao.save(dept);
					}
				});
	}

	public Dept getDeptByCondition(Dept dept) {

		return deptDao.getDeptByCondition(dept);
	}
}
