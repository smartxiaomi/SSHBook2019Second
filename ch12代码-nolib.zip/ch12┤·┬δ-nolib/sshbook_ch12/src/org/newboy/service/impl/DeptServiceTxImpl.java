package org.newboy.service.impl;


import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.newboy.service.DeptService;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

public class DeptServiceTxImpl implements DeptService {
	private DeptDao deptDao;


	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}

	public List<Dept> getAllDept() {
		return deptDao.getAllDept();
	}

	public Integer save(Dept dept) {
		return deptDao.save(dept);
	}

	public Dept getDeptByCondition(Dept dept) {

		return deptDao.getDeptByCondition(dept);
	}
}
