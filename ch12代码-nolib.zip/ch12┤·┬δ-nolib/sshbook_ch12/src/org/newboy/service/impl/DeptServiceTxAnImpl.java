package org.newboy.service.impl;


import java.util.List;

import org.newboy.dao.DeptDao;
import org.newboy.entity.Dept;
import org.newboy.service.DeptService;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

public class DeptServiceTxAnImpl implements DeptService {

	//ʹ��ע��ķ�ʽ����get����֧������
    @Transactional(propagation=Propagation.SUPPORTS)
	public List<Dept> getAllDept() {
		return deptDao.getAllDept();
	}
    
	@Transactional(propagation=Propagation.REQUIRED)
	public Integer save(Dept dept) {
		return deptDao.save(dept);
	}
	
	public Dept getDeptByCondition(Dept dept) {

		return deptDao.getDeptByCondition(dept);
	}

	public void setDeptDao(DeptDao deptDao) {
		this.deptDao = deptDao;
	}
	
	private DeptDao deptDao;
}
