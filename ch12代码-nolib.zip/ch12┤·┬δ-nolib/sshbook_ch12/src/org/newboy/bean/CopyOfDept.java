package org.newboy.bean;

import java.util.HashSet;
import java.util.Set;

import org.newboy.entity.Emp;

/**
 * ����ʵ����
 */
public class CopyOfDept implements java.io.Serializable {
	private Integer deptno;	//���ű��
	private String dname;		//��������
	private String loc;			//���ڳ���
	private Set<Emp> emps = new HashSet<Emp>(0);		//һ�Զ�Ĺ�ϵ

	public CopyOfDept() {
	}

	public CopyOfDept(Integer deptno) {
		this.deptno = deptno;
	}

	public CopyOfDept(Integer deptno, String dname, String loc, Set<Emp> emps) {
		this.deptno = deptno;
		this.dname = dname;
		this.loc = loc;
		this.emps = emps;
	}

	public Integer getDeptno() {
		return this.deptno;
	}

	public void setDeptno(Integer deptno) {
		this.deptno = deptno;
	}

	public String getDname() {
		return this.dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLoc() {
		return this.loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public Set<Emp> getEmps() {
		return this.emps;
	}

	public void setEmps(Set<Emp> emps) {
		this.emps = emps;
	}

}