package action;

import com.biz.UserBiz;

public class UserAction {
	
	private UserBiz userbiz=null;
	//��Ӧҳ���������.
	private String userName;
	

	private String password;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
		
	public String execute(){
		if(userbiz.checkUser(userName, password)){
			return "success";
		}else{
			return "fail";	
		}
	}

	public UserBiz getUserbiz() {
		return userbiz;
	}
	public void setUserbiz(UserBiz userbiz) {
		this.userbiz = userbiz;
	}
}
