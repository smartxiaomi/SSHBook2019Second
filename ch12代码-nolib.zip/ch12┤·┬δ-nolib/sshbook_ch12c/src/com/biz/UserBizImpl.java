package com.biz;

public class UserBizImpl implements UserBiz {

	public boolean checkUser(String userName, String password) {
		if (userName.equals("jack") && password.equals("123456"))
			return true;
		else
			return false;
	}

}
