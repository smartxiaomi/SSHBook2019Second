package com.biz;

public interface UserBiz {
	
	public boolean checkUser(String userName,String password);

}
