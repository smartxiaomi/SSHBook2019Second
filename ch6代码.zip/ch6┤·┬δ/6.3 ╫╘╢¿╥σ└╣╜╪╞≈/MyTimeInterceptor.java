package cn.e307.mvc.interceptor;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class MyTimeInterceptor extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {

		long currentTime = System.currentTimeMillis();

		String result = invocation.invoke(); // �Һ��������������򵽴�action

		long interval = System.currentTimeMillis() - currentTime;
		System.out.println("����ʱ����" + interval);
		return result;
	}

}
