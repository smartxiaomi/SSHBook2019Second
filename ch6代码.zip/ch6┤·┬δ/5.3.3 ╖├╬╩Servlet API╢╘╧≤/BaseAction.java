package cn.e307.mvc.action;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import com.opensymphony.xwork2.ActionSupport;

public class BaseAction extends ActionSupport 
						implements ServletRequestAware,
								   SessionAware, 
								   ServletContextAware,RequestAware {
	
	protected HttpServletRequest request;//ServletRequestAware
	protected Map<String,Object> req;//RequestAware
	
	protected ServletContext application;
	
	protected Map<String, Object> session;
	

	//ͬʱҪʵ����������setter��������Struts2���ע��ʹ��
	public void setServletContext(ServletContext application) {
		this.application = application;
	}

	public void setSession(Map<String, Object> session) {
		this.session = session;
	}

	public void setServletRequest(HttpServletRequest request) {
		this.request = request;
	}

	public void setRequest(Map<String, Object> arg0) {
		// TODO Auto-generated method stub
		
	}
}
