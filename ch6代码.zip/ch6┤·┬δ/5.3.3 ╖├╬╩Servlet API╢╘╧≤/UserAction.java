package cn.e307.mvc.action;

import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.RequestAware;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.interceptor.SessionAware;
import org.apache.struts2.util.ServletContextAware;

import cn.e307.mvc.bean.User;
import cn.e307.mvc.dao.impl.UserDaoImpl;
import cn.e307.mvc.entity.Users;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;

public class UserAction extends BaseAction {
	//�����ύ���û���
	private String username;
	//�����ύ������
	private String password;

	private Users user;

	private String nextPage;

	@Override
	public String execute() throws Exception {
		//ActionContext.getContext().getSession();
		//ServletActionContext.getRequest().getSession();
		
		if ("mike".equals(username)) {
			//ֱ�ӻ�ȡ����BaseAction��session����
			super.session.put("current_user", username);
			return SUCCESS;
		} else {
			return ERROR;
		}

	}
	
	// getter��setter����ʡ��

	@Override
	public void validate() { // input
		if (this.username == null || this.username.length() == 0) {
			super.addFieldError("username", getText("register.username.null"));
		}
		if (this.password == null || this.password.length() == 0) {
			super.addFieldError("password", getText("register.password.null"));
		}
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public String getNextPage() {
		return nextPage;
	}

}
