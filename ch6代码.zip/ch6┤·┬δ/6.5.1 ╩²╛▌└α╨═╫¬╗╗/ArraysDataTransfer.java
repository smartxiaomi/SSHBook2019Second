package cn.e307.mvc.action;

import java.util.Date;

import com.opensymphony.xwork2.ActionSupport;

public class ArraysDataTransfer extends ActionSupport {

	//���յ�һ�������
	private String[] hobbies;
	
	//���յڶ��������
	private Double[] numbers = new Double[3];
	
	private Date timeDate;
	
	private int txtNumber;
	
	@Override
	public String execute() throws Exception {
		for (int i = 0; i < hobbies.length; i++) {
			System.out.println(hobbies[i]);
		}
		System.out.println("==================================");
		
		for (int i = 0; i < numbers.length; i++) {
			System.out.println(numbers[i]);
		}
		return SUCCESS;
	}

	//getter��setterʡ��
	public String[] getHobbies() {
		return hobbies;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}

	public Double[] getNumbers() {
		return numbers;
	}

	public void setNumbers(Double[] numbers) {
		this.numbers = numbers;
	}

	public Date getTimeDate() {
		return timeDate;
	}

	public void setTimeDate(Date timeDate) {
		this.timeDate = timeDate;
	}

	public int getTxtNumber() {
		return txtNumber;
	}

	public void setTxtNumber(int txtNumber) {
		this.txtNumber = txtNumber;
	}
	
	
}
