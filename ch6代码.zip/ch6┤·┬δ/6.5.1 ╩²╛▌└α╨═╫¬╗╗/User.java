package cn.jbit.bean;

/**
 * 用户类
 * @author Administrator
 *
 */
public class User {
	//姓名
	private String name; 
	//年龄
	private int age;     
	//住址
	private Address address;
	
	//getter和  setter方法省略
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
