package cn.jbit.action;

import java.util.Date;

import com.opensymphony.xwork2.ActionSupport;

public class DateConvertAction extends ActionSupport {
	
	//���ձ��������������
	private Date timeDate;
	
	@Override
	public String execute() throws Exception {
		return SUCCESS;
	}

	public Date getTimeDate() {
		return timeDate;
	}

	public void setTimeDate(Date timeDate) {
		this.timeDate = timeDate;
	}
	
	
}
