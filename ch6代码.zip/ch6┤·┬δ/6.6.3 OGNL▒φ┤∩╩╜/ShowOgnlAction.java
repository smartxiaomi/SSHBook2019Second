package cn.e307.mvc.action;

import java.util.ArrayList;
import java.util.List;

import cn.e307.mvc.bean.Book;

public class ShowOgnlAction extends BaseAction {  // ValueStack	
	
	//图书列表
	private List<Book> bookList = new ArrayList<Book>();
	
	@Override
	public String execute() throws Exception {
		
		request.setAttribute("info", "Mike in RequestScope.");
		session.put("info", "Mike in SessionScope.");
		application.setAttribute("info", "Mike in applicationScope.");
		session.put("msg", "good morning");
		
		bookList.add(new Book("西游记", "4324-4234-2424", 100));
		bookList.add(new Book("红楼梦", "24-242-2424", 50));
		bookList.add(new Book("三国演义", "4324-4234-2424", 89));
		bookList.add(new Book("水浒传", "244-4234-2424", 76));
		
		return SUCCESS;
	}

	public List<Book> getBookList() {
		return bookList;
	}

	public void setBookList(List<Book> bookList) {
		this.bookList = bookList;
	}
}
