package cn.mvc.reflect;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//ͨ�û�
		String str = new String();
		
		try {
			
			Class clz = Class.forName("cn.mvc.test.web.AddAction");
			clz.newInstance();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InstantiationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
