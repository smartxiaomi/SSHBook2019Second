package cn.mvc.struts.framework;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface Action {

	/**
	 * �����û�����
	 * 
	 * @param request
	 * @param response
	 * @return ת����ҳ���ַ
	 */
	public String execute(HttpServletRequest request,
			HttpServletResponse response);

}
