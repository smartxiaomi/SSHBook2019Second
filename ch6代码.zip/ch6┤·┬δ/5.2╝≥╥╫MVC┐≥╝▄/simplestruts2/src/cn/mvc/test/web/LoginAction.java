package cn.mvc.test.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.mvc.model.UserService;
import cn.mvc.struts.framework.Action;

public class LoginAction implements Action {

	public String execute(HttpServletRequest request,
			HttpServletResponse response) {
		//��ȡ�ύ����
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		
		//����ģ�Ͳ�
		UserService userService = new UserService();
		boolean result = userService.login(username, password);
		
		//�ж��û��Ƿ����
		if (result) {
			//�����û���Ϣ��session
			request.getSession().setAttribute("user", username);
			return "success.jsp";
		} else {
			return "login.jsp";
		}
	}
}
