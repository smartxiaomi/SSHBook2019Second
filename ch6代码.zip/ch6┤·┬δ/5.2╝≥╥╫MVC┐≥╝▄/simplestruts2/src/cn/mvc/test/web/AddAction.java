package cn.mvc.test.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.mvc.struts.framework.Action;

public class AddAction implements Action {

	public String execute(HttpServletRequest request,
			HttpServletResponse response) {
		
		int num1 = Integer.parseInt(request.getParameter("num1"));
		int num2 = Integer.parseInt(request.getParameter("num2"));
		
		int result = num1 + num2;
		request.setAttribute("result", result);
		
		return "add_result.jsp";
	}

}
