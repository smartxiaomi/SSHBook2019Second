package cn.mvc.model;

public class UserService {

	/**
	 * �û���¼ҵ�񷽷�
	 * @param username �û���
	 * @param password ����
	 * @return
	 */
	public boolean login(String username,String password){
		if ("admin".equals(username) && "123".equals(password)) {
			return true;
		}
		return false;
	}
}
