package cn.jbit.hibernatedemo.test;

import org.hibernate.HibernateException;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.classic.Session;
import org.junit.Test;

import cn.jbit.hibernatedemo.entity.Dept;

public class T1 {
	/**
	 * 新增Dept
	 */
	@Test
	public void eg7_saveDept() {
		Dept dept = new Dept();
//		dept.setDeptNo(new Byte("13"));
		dept.setDeptName("测试部1");
		dept.setLocation("东区");
		// 省略部分代码
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction tx = null;
		try {
			// 1.读取配置文件
			conf = new Configuration().configure();
			// 2.创建SessionFactory
			sessionFactory = conf.buildSessionFactory();
			// 3. 打开session
			session = sessionFactory.openSession();
			// 4. 开始一个事务
			tx = session.beginTransaction();
			// 5. 持久化操作
			session.save(dept);
			// 6. 提交事务
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			// 6. 回滚事务
			tx.rollback();
		} finally {
			// 7. 关闭session
			if (session != null)
				session.close();
		}

	}
	/**
	 * 按主键获取Dept对象，get方法
	 */
	@Test
	public void eg5_getDept() {
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		try {
			// 1.读取配置文件
			conf = new Configuration().configure();
			// 2.创建SessionFactory
			sessionFactory = conf.buildSessionFactory();
			// 3. 打开session
			session = sessionFactory.openSession();
			// 4. 加载数据操作
			Dept dept = (Dept) session.get(Dept.class, new Byte("1"));
			// 5. 输出数据
			System.out.println(dept.getDeptName());
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// 5. 关闭session
			if (session != null)
				session.close();
		}

	}
	/**
	 * 按主键获取Dept对象，load方法
	 */
	@Test
	public void eg6_loadDept() {
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		try {
			// 1.读取配置文件
			conf = new Configuration().configure();
			// 2.创建SessionFactory
			sessionFactory = conf.buildSessionFactory();
			// 3. 打开session
			session = sessionFactory.openSession();
			// 4. 加载数据操作
			Dept dept = (Dept) session.load(Dept.class, new Byte("11"));
			// 5. 输出数据
			System.out.println(dept.getDeptName());
		} catch (HibernateException e) {
			e.printStackTrace();
		} finally {
			// 5. 关闭session
			if (session != null)
				session.close();
		}

	}
	/**
	 * 修改部门信息，Dept对象处于持久状态
	 */
	@Test
	public void eg8_updateDept1() {
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction tx = null;
		try {
			// 1.读取配置文件
			conf = new Configuration().configure();
			// 2.创建SessionFactory
			sessionFactory = conf.buildSessionFactory();
			// 3. 打开session
			session = sessionFactory.openSession();
			// 4. 开始一个事务
			tx = session.beginTransaction();
			//  获取部门对象
			Dept dept = (Dept) session.load(Dept.class, new Byte("11"));
			// 5. 修改部门信息
			dept.setDeptName("质管部");
			// 6. 提交事务
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			// 6. 回滚事务
			tx.rollback();
		} finally {
			// 7. 关闭session
			if (session != null)
				session.close();
		}

	}

	/**
	 * 修改部门信息，Dept对象处于游离状态或游离状态
	 */
	@Test
	public void updateDept2() {
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction tx = null;
		try {
			// 1.读取配置文件
			conf = new Configuration().configure();
			// 2.创建SessionFactory
			sessionFactory = conf.buildSessionFactory();
			// 3. 打开session
			session = sessionFactory.openSession();
			// 4. 开始一个事务
			tx = session.beginTransaction();
			//  创建部门对象
			Dept dept =new Dept();
			dept.setDeptNo(new Byte("11"));
			// 部门信息
			dept.setDeptName("质管部");
			dept.setLocation("西区");
			// 5.修改Dept对象的状态，Dept对象由游离状态转为持久状态
			session.update(dept);
			// 6. 提交事务
			tx.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			// 6. 回滚事务
			tx.rollback();
		} finally {
			// 7. 关闭session
			if (session != null)
				session.close();
		}
	}
	/**
	 * 删除部门
	 */
	@Test
	public void eg9_deleteDept() {
		Configuration conf = null;
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction tx = null;
		try {
		    //1.读取配置文件
		    conf = new Configuration().configure();
		    //2.创建SessionFactory
		    sessionFactory = conf.buildSessionFactory();
		    //3. 打开session
		    session = sessionFactory.openSession();
		    //4. 开始一个事务
		    tx = session.beginTransaction();
		    //  获取部门对象
		    Dept dept=(Dept) session.load(Dept.class,new Byte("11"));
			//5. 持久化操作
		    session.delete(dept);
		    //6. 提交事务
		    tx.commit();
		} catch (HibernateException e) {
		    e.printStackTrace();
		    //6. 回滚事务
		    tx.rollback();
		} finally{
		    //7. 关闭session
			if(session!=null)
				session.close();
		}
	}


}
