﻿;package cn.e307.hiber.junit;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Restrictions;
import org.junit.BeforeClass;
import org.junit.Test;

import cn.e307.hiber.entity.Dept;
import cn.e307.hiber.entity.Emp;
import cn.e307.hiber.util.HibernateSessionUtil;
import cn.e307.hiber.util.Tool;

public class DeptTest {	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}
	
	@Test
	public void testDeptId(){
		try {
			//sSession session = HibernateUtils.getSession();
		
//			Dept dept = (Dept) session.get(Dept.class, new Integer(11));
//			
//			//Set<Emp> list = dept.getEmps();
//			
//			for (Emp emp : list) {
//				System.out.println(emp.getEmpno()+"\t"+emp.getEname()+"\t"+emp.getSal());
//			}
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			HibernateSessionUtil.closeSession();
		}
	}
	

	@Test
	public void testAdd() {
		Transaction tx = null;
		try {
			Session session = HibernateSessionUtil.getSession();
			Query query = session.getNamedQuery("findEmpByJob");
//			Dept d = new Dept();
//			d.setDname("财务部");
//			d.setLoc("东区");
//			session.createCriteria(Dept.class).add(Example.create(d));

			// 4. 打开事务
			tx = session.beginTransaction();

			// 5.持久化操作
			Dept dept = new Dept(); // 瞬时
			dept.setDeptno(16);
			dept.setDname("学术部2");
			dept.setLoc("中大校区");

			session.saveOrUpdate(dept); // 持久 托管

			tx.commit();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.rollback();
		} finally {
			HibernateSessionUtil.closeSession(); // 游离 脱管
		}
	}

	@Test
	public void testUpdate() {
		Transaction tx = null;
		try {
			Session session = HibernateSessionUtil.getSession();

			// 4. 打开事务
			tx = session.beginTransaction();

			// 5.持久化操作
			Dept dept2 = (Dept) session.get(Dept.class, new Integer(10)); // 反射
																			// 一级缓存
			// Dept dept2 = (Dept) session.get(Dept.class, new Integer(10));
			// //反射
			// System.out.println(dept==dept2);
			// dept.setDname("yyyy");
			// Dept dept = (Dept) session.load(Dept.class, new Integer(1500));
			// System.out.println(dept.getDname());
			// dept.setDname("总经理办公室");
			// session.update(dept);
			// session.saveOrUpdate(dept);
			Dept dept = new Dept(); // 瞬时
			dept.setDeptno(10);
			dept.setDname("学术部2");
			dept.setLoc("中大校区");
			// session.saveOrUpdate(dept);
			session.merge(dept);
			// session.flush();
			tx.commit();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.rollback();
		} finally {
			HibernateSessionUtil.closeSession();
		}
	}

	@Test
	public void testQuery() {
		try {
			Session session = HibernateSessionUtil.getSession();

			List<Emp> list = session.createQuery("from Emp").list();
			for (Emp emp : list) {
				if (emp.getDept() != null) {
					System.out.println(emp.getEname() + "\t" + emp.getSal() + "\t"
							+ emp.getDept().getDname());
				} else{
					System.out.println(emp.getEname() + "\t" + emp.getSal() + "\t" + "临工");
				}
				
			}

		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			HibernateSessionUtil.closeSession(); // 游离 脱管
		}
	}

}
