package org.newboy.ch1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class BaseDao {
	private static final String DRIVE = "oracle.jdbc.driver.OracleDriver";
	private static final String URL = "jdbc:oracle:thin:@localhost:1521:orcl";
	private static final String DBUSER = "system";
	private static final String DBPWD = "abc";
	protected Connection con;
	protected PreparedStatement ps;
	protected ResultSet rs;
	/**
	 * 1
	 * @return Connection
	 */
	public  Connection getCon() {
		try {
			Class.forName(DRIVE);
			con = DriverManager.getConnection(URL, DBUSER, DBPWD);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return con;
	}

	/**
	 * 2.
	 * @param rs
	 * @param st
	 * @param con
	 */
	public static void closeAll(ResultSet rs, Statement st, Connection con) {

		try {
			if (rs != null)
				rs.close();

			if (st != null)
				st.close();

			if (con != null)
				con.close();

		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	/**
	 * 3.ִ
	 * 
	 * @param sql
	 * @param param
	 * @return 
	 */
	public  int executeSQL(String sql, Object[] param) {
		int rows = 0;
		
		try {
			con = getCon();
			ps = con.prepareStatement(sql);
			if (param != null) {
				for (int i = 0; i < param.length; i++) {
					//
					ps.setString(i + 1, param[i].toString());
				}
			}
			rows = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			closeAll(null, ps, con);
		}
		return rows;
	}
}