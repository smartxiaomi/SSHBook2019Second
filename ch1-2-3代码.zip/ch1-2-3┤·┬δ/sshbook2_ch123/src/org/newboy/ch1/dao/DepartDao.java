package org.newboy.ch1.dao;

import java.util.List;

import org.newboy.ch1.entity.Depart;

public interface DepartDao {
	
	//get all department
	public List<Depart> getAllDepart();
	
	//get Department by department's Id
	public Depart getDepartById(int dno);
	

}
