package org.newboy.ch1;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class JdbcDemo {

	/**
	 * @param args
	 * @throws SQLException
	 */
	public static void main(String[] args) {
		executeInsert();
		executeQuery();
	}

	/**
	 * 
	 */
	public static void executeInsert() {
		Connection conn = null;
		Statement stmt = null;
		try {
			// 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
			stmt = conn.createStatement();
			String sql = "insert into DEPT(DEPTNO,DNAME,LOC)values(100,'Development_Depart','Beijing')";
			int row = stmt.executeUpdate(sql);
			if (row > 0) {
				System.out.println("Success");
			} else {
				System.out.println("ִinsert Fail");
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				stmt.close();// 
				conn.close(); // 
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

	/**
	 * ��ѯ���в�����Ϣ�Ĳ�����Ϣ���ڿ���̨��ӡ
	 */
	public static void executeQuery() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		try {
			// 
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:orcl", "scott", "tiger");
			stmt = conn.createStatement();
			String sql = "select DEPTNO,DNAME,LOC from DEPT";
			rs = stmt.executeQuery(sql);
			while (rs.next()) {
				int dno = rs.getInt("deptno"); // deptno
				String dname = rs.getString("dname");
				String loc = rs.getString("loc");
				System.out.println("DNo:" + dno + ", Depart Name:" + dname
						+ ", Location" + loc);

			}

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();// 
				stmt.close();// 
				conn.close(); // 
			} catch (SQLException e) {
				e.printStackTrace();
			}

		}
	}

}
