package cn.e307.hiber.dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import cn.e307.hiber.dao.DeptDao;
import cn.e307.hiber.entity.Dept;
import cn.e307.hiber.util.HibernateSessionUtil;

public class DeptDaoImpl implements DeptDao {

	public Dept getDept(Integer id) {
		Session session = HibernateSessionUtil.getSessionFactory()
				.getCurrentSession();
		return (Dept) session.get(Dept.class, id);
	}

	@Override
	public void saveDept(Dept dept) {
		Session session = HibernateSessionUtil.getSessionFactory()
				.getCurrentSession();
		session.save(dept);
	}
}
