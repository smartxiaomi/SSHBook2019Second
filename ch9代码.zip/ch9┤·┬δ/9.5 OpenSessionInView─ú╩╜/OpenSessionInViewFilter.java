package cn.e307.hiber.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import cn.e307.hiber.util.HibernateSessionUtil;

public class OpenSessionInViewFilter implements Filter {
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		Transaction tx = null;
		try {
			//HibernateSessionUtil.getSession()
			Session session = HibernateSessionUtil.getSessionFactory()
					.getCurrentSession();
			
			tx = session.beginTransaction();
			
			chain.doFilter(request, response);//访问要请求的资源
			//返回响应时提交事务
			tx.commit();
		} catch (HibernateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			tx.rollback();
		} finally {
			//关闭时，必须调用下面closeSession()关闭
			HibernateSessionUtil.closeSession();
		}
	}
	
	public void init(FilterConfig arg0) throws ServletException {
	}
	
	public void destroy() {
	}
}
