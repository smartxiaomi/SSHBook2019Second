package cn.e307.hiber.entity;

import java.lang.Integer;
import java.util.HashSet;
import java.util.Set;

/**
 * Employ entity. @author MyEclipse Persistence Tools
 */

public class Employ implements java.io.Serializable {

	// Fields

	private Integer employeeid;
	private String employeename;
	private String employeedesc;
	private Set projects = new HashSet(0);

	// Constructors

	/** default constructor */
	public Employ() {
	}

	/** minimal constructor */
	public Employ(String employeename) {
		this.employeename = employeename;
	}

	/** full constructor */
	public Employ(String employeename, String employeedesc, Set projects) {
		this.employeename = employeename;
		this.employeedesc = employeedesc;
		this.projects = projects;
	}

	// Property accessors

	public Integer getEmployeeid() {
		return this.employeeid;
	}

	public void setEmployeeid(Integer employeeid) {
		this.employeeid = employeeid;
	}

	public String getEmployeename() {
		return this.employeename;
	}

	public void setEmployeename(String employeename) {
		this.employeename = employeename;
	}

	public String getEmployeedesc() {
		return this.employeedesc;
	}

	public void setEmployeedesc(String employeedesc) {
		this.employeedesc = employeedesc;
	}

	public Set getProjects() {
		return this.projects;
	}

	public void setProjects(Set projects) {
		this.projects = projects;
	}

}