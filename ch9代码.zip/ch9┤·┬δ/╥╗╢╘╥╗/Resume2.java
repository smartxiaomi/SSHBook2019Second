package cn.e307.hiber.entity;

/**
 * Resume2 entity. @author MyEclipse Persistence Tools
 */

public class Resume2 implements java.io.Serializable {

	// Fields

	private Integer resid;
	private String resname;
	private String rescardno;
	private Users2 users2;

	// Constructors

	/** default constructor */
	public Resume2() {
	}

	/** minimal constructor */
	public Resume2(Integer resid, String resname, String rescardno) {
		this.resid = resid;
		this.resname = resname;
		this.rescardno = rescardno;
	}

	/** full constructor */
	public Resume2(Integer resid, String resname, String rescardno,
			Users2 users2) {
		this.resid = resid;
		this.resname = resname;
		this.rescardno = rescardno;
		this.users2 = users2;
	}

	// Property accessors

	public Integer getResid() {
		return this.resid;
	}

	public void setResid(Integer resid) {
		this.resid = resid;
	}

	public String getResname() {
		return this.resname;
	}

	public void setResname(String resname) {
		this.resname = resname;
	}

	public String getRescardno() {
		return this.rescardno;
	}

	public void setRescardno(String rescardno) {
		this.rescardno = rescardno;
	}

	public Users2 getUsers2() {
		return this.users2;
	}

	public void setUsers2(Users2 users2) {
		this.users2 = users2;
	}

}