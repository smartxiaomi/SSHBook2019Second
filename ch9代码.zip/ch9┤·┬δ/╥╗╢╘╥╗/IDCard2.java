package org.newboy.entity;

public class IDCard2 {
	private int id;
	private String idno;
	private Citizen2 citizen2;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIdno() {
		return idno;
	}
	public void setIdno(String idno) {
		this.idno = idno;
	}
	public Citizen2 getCitizen2() {
		return citizen2;
	}
	public void setCitizen2(Citizen2 citizen2) {
		this.citizen2 = citizen2;
	}
	
	
}
