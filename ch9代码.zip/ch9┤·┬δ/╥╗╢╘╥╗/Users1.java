package cn.e307.hiber.entity;

/**
 * Users1 entity. @author MyEclipse Persistence Tools
 */

public class Users1 implements java.io.Serializable {

	// Fields

	private Integer userid;
	private String username;
	private String userpass;
	private Resume1 resume1;

	// Constructors

	/** default constructor */
	public Users1() {
	}

	/** minimal constructor */
	public Users1(Integer userid, String username, String userpass) {
		this.userid = userid;
		this.username = username;
		this.userpass = userpass;
	}

	/** full constructor */
	public Users1(Integer userid, String username, String userpass,
			Resume1 resume1) {
		this.userid = userid;
		this.username = username;
		this.userpass = userpass;
		this.resume1 = resume1;
	}

	// Property accessors

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpass() {
		return this.userpass;
	}

	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}

	public Resume1 getResume1() {
		return this.resume1;
	}

	public void setResume1(Resume1 resume1) {
		this.resume1 = resume1;
	}

}