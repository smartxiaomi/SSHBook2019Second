package org.newboy.entity;

public class IDCard1 {
	private int id;
	private String idno;
	private Citizen1 citizen1;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getIdno() {
		return idno;
	}
	public void setIdno(String idno) {
		this.idno = idno;
	}
	public Citizen1 getCitizen1() {
		return citizen1;
	}
	public void setCitizen1(Citizen1 citizen1) {
		this.citizen1 = citizen1;
	}
	
	
}
