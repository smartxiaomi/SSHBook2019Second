package cn.e307.hiber.entity;

/**
 * Users2 entity. @author MyEclipse Persistence Tools
 */

public class Users2 implements java.io.Serializable {

	// Fields

	private Integer userid;
	private Resume2 resume2;
	private String username;
	private String userpass;

	// Constructors

	/** default constructor */
	public Users2() {
	}

	/** full constructor */
	public Users2(Resume2 resume2, String username, String userpass) {
		this.resume2 = resume2;
		this.username = username;
		this.userpass = userpass;
	}

	// Property accessors

	public Integer getUserid() {
		return this.userid;
	}

	public void setUserid(Integer userid) {
		this.userid = userid;
	}

	public Resume2 getResume2() {
		return this.resume2;
	}

	public void setResume2(Resume2 resume2) {
		this.resume2 = resume2;
	}

	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpass() {
		return this.userpass;
	}

	public void setUserpass(String userpass) {
		this.userpass = userpass;
	}

}