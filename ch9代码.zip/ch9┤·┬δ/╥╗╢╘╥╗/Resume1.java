package cn.e307.hiber.entity;

/**
 * Resume1 entity. @author MyEclipse Persistence Tools
 */

public class Resume1 implements java.io.Serializable {

	// Fields

	private Integer resid;
	private Users1 users1;
	private String resname;
	private String rescardno;

	// Constructors

	/** default constructor */
	public Resume1() {
	}

	/** minimal constructor */
	public Resume1(Integer resid, String resname, String rescardno) {
		this.resid = resid;
		this.resname = resname;
		this.rescardno = rescardno;
	}

	/** full constructor */
	public Resume1(Integer resid, Users1 users1, String resname,
			String rescardno) {
		this.resid = resid;
		this.users1 = users1;
		this.resname = resname;
		this.rescardno = rescardno;
	}

	// Property accessors

	public Integer getResid() {
		return this.resid;
	}

	public void setResid(Integer resid) {
		this.resid = resid;
	}

	public Users1 getUsers1() {
		return this.users1;
	}

	public void setUsers1(Users1 users1) {
		this.users1 = users1;
	}

	public String getResname() {
		return this.resname;
	}

	public void setResname(String resname) {
		this.resname = resname;
	}

	public String getRescardno() {
		return this.rescardno;
	}

	public void setRescardno(String rescardno) {
		this.rescardno = rescardno;
	}

}