package cn.e307.hiber.entity;


import java.util.Date;

/**
 * Emp entity. @author MyEclipse Persistence Tools
 */

public class Emp implements java.io.Serializable {

	// Fields

	private Long empno;
	private Dept dept;
	private String ename;
	private String job = "工程师";
	private Double sal = 3000.00;
	private Date hiredate = new Date();

	// Constructors

	/** default constructor */
	public Emp() {
	}
	
	public Emp(String ename,Double sal) {
		this.ename = ename;
		this.sal = sal;
	}

	/** minimal constructor */
	public Emp(Long empno) {
		this.empno = empno;
	}

	/** full constructor */
	public Emp(Long empno, Dept dept, String ename, String job, Double sal,
			Date hiredate) {
		this.empno = empno;
		this.dept = dept;
		this.ename = ename;
		this.job = job;
		this.sal = sal;
		this.hiredate = hiredate;
	}

	// Property accessors

	public Long getEmpno() {
		return this.empno;
	}

	public void setEmpno(Long empno) {
		this.empno = empno;
	}

	public Dept getDept() {
		return this.dept;
	}

	public void setDept(Dept dept) {
		this.dept = dept;
	}

	public String getEname() {
		return this.ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getJob() {
		return this.job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public Double getSal() {
		return this.sal;
	}

	public void setSal(Double sal) {
		this.sal = sal;
	}

	public Date getHiredate() {
		return this.hiredate;
	}

	public void setHiredate(Date hiredate) {
		this.hiredate = hiredate;
	}

}